<?php
require_once(__DIR__.'/../../AbstractHarvester.php');
include_once(__DIR__.'/AdcISOXmlHarvestTrait.php');
include_once(__DIR__.'/../cache/simple_html_dom.php');
$env = isset($argv[1]) ? $argv[1] : "stage";
$config=file_get_contents("../jornada_config_".$env.".json");
$config_json = json_decode($config);
class JerHarvester extends AbstractHarvester {    
    use AdcISOXmlHarvestTrait;
    
    public function harvest() {
        try {
            // date_default_timezone_set("America/New_York");
            $base_url=$this->base_url;
            $config_json=$this->config_json;
            $env=$this->env;
            $file_path="../../file_cache/jornada/";
            $JER_metadata_file = file_get_contents("../migrate/logs/".$env."/Jer_records.json");
            $json_a = json_decode($JER_metadata_file, true);
            $JER_harvested_metadata_file = file_get_contents("../migrate/logs/".$env."/Jer_harvested_records.json");
            $json_harvested = json_decode($JER_harvested_metadata_file, true);
            $event_log = fopen("../migrate/logs/".$env."/Jer_metadata_report.txt", "a");
            $error_log = fopen("../migrate/logs/".$env."/Jer_metadata_error.txt", "a");
            $metadata_adc_links_file = file_get_contents("../migrate/logs/".$env."/Jer_metadata_links.json");
            $metadata_adc_links=json_decode($metadata_adc_links_file, true);
            $dir_handle = opendir($file_path);
            $updated=0;
            $new_added=0;
            $failed=0;
            $unchanged=0;
            while(($file_name = readdir($dir_handle)) !== false) 
            { 
                if ($file_name == "." || $file_name == ".."||str_contains($file_name,"EML")) {
                    continue;
                }
                $ediid=explode(".",$file_name)[0].'.'.explode(".",$file_name)[1];
                $lastid=str_replace("_ISO19139","",explode(".",$file_name)[1].'.'.explode(".",$file_name)[2]);

                
                if(isset($json_harvested[$ediid])&&$json_harvested[$ediid]==$lastid){
                    $unchanged++;
                    // continue;
                // check if a record is in the exclusion lists
                }elseif(!isset($json_harvested[$ediid])&&isset($json_a[$ediid])&&$json_a[$ediid]==$lastid){
                    continue;
                }
                $file_name_with_full_path=$file_path."/".$file_name;
                $uuid=str_replace("_ISO19139.xml","",$file_name);

                $jsonData= $this->iso_mapping($file_name_with_full_path,$config_json,$ediid);
                $jsonData=$this->related_material($jsonData,$uuid);
                var_dump("<pre>");
                echo json_encode($jsonData);
                // newly added
                if(!isset($json_harvested[$ediid])){
                    echo "need to create new records";
                    $res=$this->figshare_api_req($jsonData);
                    var_dump($res);
                    if(isset($res['entity_id'])){
                        $figshare_nodeid=$res['entity_id'];
                        $json_harvested[$ediid]=$lastid;
                        $res=$this->figshare_api_req_update($figshare_nodeid,$jsonData);
                        $split_ar=explode('.',$ediid);
                        $remote_file=array('link'=>'https://portal.edirepository.org/nis/mapbrowse?scope=knb-lter-jrn&identifier='.trim($split_ar[1]));
                        $res2=$this->figshare_api_remote_file($figshare_nodeid,$remote_file);
                        $publish = $this->figshare_api_publish($figshare_nodeid);
                        $new_added++;
                        $metadata_adc_links[$ediid]=$figshare_nodeid;
                    }else{
                        $failed++;
                        fwrite($error_log, $lastid.' failed on '.date("Y/m/d").' at '.date("h:i:sa").' Error message:'.$res['message'].PHP_EOL);
                    }
                }else{
                    // update previously harvested record
                    $figshare_nodeid=$metadata_adc_links[$ediid];
                    $res=$this->figshare_api_req_update($figshare_nodeid,$jsonData);
                    var_dump($res);
                    $publish = $this->figshare_api_publish($figshare_nodeid);
                    if(isset($res['location'])){
                        $updated++;
                        $json_harvested[$ediid]=$lastid;
                    }else{
                        $failed++;
                        fwrite($error_log, $lastid.' failed on '.date("Y/m/d").' at '.date("h:i:sa").' to update. Error message:'.json_encode($res).PHP_EOL);
                    }
                    // break;
                }
            }
            fwrite($event_log, 'Last run on '.date("Y/m/d").' at '.date("h:i:sa").'; '.$new_added.' added; '.$updated.' updated; '.$failed.' failed; '.$unchanged.' unchanged'.PHP_EOL);
            
            fclose($record_version_mapping);
            // $record_harvested = fopen('logs/'.$env.'/Jer_harvested_records.json', 'w');
            // fwrite($record_harvested, json_encode($json_harvested));
            $record_harvested_figshare_link = fopen('logs/'.$env.'/Jer_metadata_links.json', 'w');
            fwrite($record_harvested_figshare_link, json_encode($metadata_adc_links));
            fclose($record_harvested);
            fclose($event_log);
            fclose($record_harvested_figshare_link);
        } catch (Exception $ex) {
            trigger_error($ex->getMessage());
        }  
    }
    private function related_material($json,$uuid){

        $related_html='https://portal.edirepository.org//nis//mapbrowse?packageid='.$uuid;
        echo $related_html;
        $html = file_get_html($related_html);
        $related_material=[];
        if ($html !== false) {
            // Find all div elements with class "table-row"
            $tableRows = $html->find('div.table-row');
        
            // Iterate through each table row
            foreach ($tableRows as $row) {
                // Find the label inside the current row
                $label = $row->find('label.labelBold', 0);
                
                // Check if the label's text matches "Journal Citations:"
                if ($label && $label->plaintext === 'Journal Citations:') {
                    $olElement = $row->find('div.table-cell ul.no-list-style li ol', 0);
                    if ($olElement) {
                        $liElements = $olElement->find('li');
                        foreach ($liElements as $li) {
                            $a = $li->find('a.searchsubcat')[0];
                            $href = $a->href;
                            $textContent = $li->plaintext;
                            $pattern = '/\((10\.\d{4,}\/\S+)\)/';
                            if(preg_match($pattern, $textContent, $matches)) {
                                $doi = $matches[1]; // The matched DOI value
                                $related_material[]=array(
                                    "identifier"=>$doi,
                                    "title"=>$textContent,
                                    "relation"=>"IsSupplementTo",
                                    "identifier_type"=>"DOI",
                                );
                            }else{
                                $related_material[]=array(
                                    "identifier"=>$href,
                                    "title"=>$textContent,
                                    "relation"=>"IsSupplementTo",
                                    "identifier_type"=>"URL",
                                );
                            }
                        }
                    }
                }
            }
        
            // Clean up memory
            $html->clear();
            if(!empty($related_material)){
                $json->related_materials = $related_material;
            }
            
        }

        return $json;
    }
    
}
