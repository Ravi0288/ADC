<?php
include_once(__DIR__.'/simple_html_dom.php');
require_once '../../utils.php';
$env = isset($argv[1]) ? $argv[1] : "stage";
$config=file_get_contents("../jornada_config_".$env.".json");
$config_json = json_decode($config);
usda_harvest_jornada_cache(date("Y-m-d"),$config_json,$env );

function usda_harvest_jornada_cache( $harvestUpdateTime,$config_json,$env ) {
    $file_path="../../file_cache/jornada/";
    $root_url='https://portal.edirepository.org/nis/identifierbrowse?scope=knb-lter-jrn';
    $html = file_get_html($root_url);
    $id_arrays=[];
    $eml_mapping = array('eml-2.1.0'=>'transforms/eml2.1.0_2iso19139.xsl','eml-2.1.1'=>'transforms/eml2.1.1_2iso19139.xsl','eml-2.2.0'=>'transforms/eml2.2.0_2iso19139.xsl');
    foreach($html->find('a') as $element){
        if(array_key_exists('class', $element->attr)){
            if($element->attr['class']=='searchsubcat'){
                $id_arrays[]=$element->text();
            }
        }
    }

    $JER_metadata_file = file_get_contents("../migrate/logs/".$env."/Jer_records.json");
    $json_a = json_decode($JER_metadata_file, true);
    $JER_harvested_metadata_file = file_get_contents("../migrate/logs/".$env."/Jer_harvested_records.json");
    $json_harvested = json_decode($JER_harvested_metadata_file, true);
    $event_log = fopen("../migrate/logs/".$env."/Jer_metadata_report.txt", "a");
    $error_log = fopen("../migrate/logs/".$env."/Jer_metadata_error.txt", "a");
    $metadata_adc_links_file = file_get_contents("../migrate/logs/".$env."/Jer_metadata_links.json");
    $metadata_adc_links=json_decode($metadata_adc_links_file, true);
    $dir_handle = opendir($file_path);
    var_dump("<pre>");
    foreach($id_arrays as $ediid){
        if(!isset($json_harvested[$ediid])&&isset($json_a[$ediid])){
            continue;
        }
        $split_ar=explode('.',$ediid);
        $root_url='https://portal.edirepository.org/nis/revisionbrowse?scope=knb-lter-jrn&identifier='.trim($split_ar[1]).'&contentType=application/xml';
        $html = file_get_html($root_url);
        $lastid='';
        foreach($html->find('a') as $element){
            if(array_key_exists('class', $element->attr)){
                if($element->attr['class']=='searchsubcat'){
                    $lastid=$element->text();
                }
            }
        }
        
        $link='https://portal.edirepository.org/nis/metadataviewer?packageid='.$lastid.'&contentType=application/xml';
        
        //check if a record needs to be updated
        if(isset($json_harvested[$ediid])&&$json_harvested[$ediid]==$lastid){
            continue;
        // check if a record is in the exclusion lists
        }elseif(!isset($json_harvested[$ediid])&&isset($json_a[$ediid])&&$json_a[$ediid]==$lastid){
            echo $ediid." not harvesting ";
            continue;
        }        
        $json_a[$ediid]=$lastid;

        $xml = simplexml_load_file($link);
        $namespaces = $xml->getNamespaces(true);
        $eml=$namespaces['eml'];
        $eml_explode = explode('/',$eml);
        $eml_version=end($eml_explode);
        $uuid=$xml->attributes();
        $keyword_list=[];
        $keywordSets=$xml->xpath('/eml:eml/dataset/keywordSet');
        foreach($keywordSets as $kwrdSet){
            $keywords=$kwrdSet->xpath('keyword');
            foreach($keywords as $kwrd){
                $keyword_list[]=$kwrd[0];
            }
        }
        
        if(in_array('LTAR',$keyword_list)||in_array('LTAR_LTER',$keyword_list)){
            $json_harvested[$ediid]=$lastid;
            $fund="";
            $xml->asXML($file_path.$uuid.'_EML.xml');
            if(array_key_exists($eml_version,$eml_mapping)){
                $rsl=transform($file_path.$uuid.'_EML.xml',$eml_mapping[$eml_version]);
                file_put_contents ($file_path.$uuid.'_ISO19139.xml',$rsl);
                $snippets = new DOMDocument;
                $snippets->load('funder_snippet.xml');
                $xpath = new DOMXPath($snippets);
                // update
                // getElementsByTagNameNS
                $xpath->registerNamespace('gmd', 'http://www.isotc211.org/2005/gmd');
                $xpath->registerNamespace('gco','http://www.isotc211.org/2005/gco');
                $val=$xpath->query("//gmd:MD_Keywords//gmd:keyword//gco:CharacterString");
                $fund = $xml->xpath('/eml:eml/dataset/project/funding/section/para');
                if(empty($fund)){
                    $fund = $xml->xpath('/eml:eml/dataset/project/funding/para');
                    if(empty($fund)){
                        $fund= $xml->xpath('/eml:eml/dataset/project/funding');
                    }
                }
                $fundref=array();
                $arsinfunding=false;
                
                foreach($fund as $fd){
                    if(str_contains($fd,"USDA Long-Term Agroecosystem Research")){
                        if(preg_match('/\d+-\d+-\d+-\d+\w+/', $fd, $matches)){
                            $grant=$matches[0];
                            $fundref[] = 'USDA-ARS, '.trim($grant);
                            $arsinfunding=true;
                        }elseif(preg_match('/\d+-\d+-\d+-\w+/', $fd, $matches)){
                            $grant=$matches[0];
                            $fundref[]='USDA-ARS, '.trim($grant);
                            $arsinfunding=true;
                        }elseif(preg_match('/\d+-\d+-\d+/', $fd, $matches)){
                            $grant=$matches[0];
                            $fundref[]='USDA-ARS, '.trim($grant);
                            $arsinfunding=true;
                        }else{
                            if(str_contains($fd,"USDA-ARS")){
                                $arsinfunding=true;
                            }
                            $fundref[]=$fd;
                        }
                    }else{
                        if(str_contains($fd,"USDA-ARS")){
                            $arsinfunding=true;
                        }
                        $fundref[]=$fd;
                    }     
                }
                if(!$arsinfunding){
                    $fundref[]='USDA-ARS';
                }
                $funding_snippets=simplexml_load_file('funder_snippet.xml');
                $funding_snippets->registerXPathNamespace('gmd', 'http://www.isotc211.org/2005/gmd');
                foreach($fundref as $frf){
                    $fundingkeyword='<gmd:keyword xmlns:gmd="http://www.isotc211.org/2005/gmd" xmlns:gco="http://www.isotc211.org/2005/gco">
                        <gco:CharacterString>fundingkeyword</gco:CharacterString>
                    </gmd:keyword>';
                    $fundingkeyword=str_replace("fundingkeyword",$frf,$fundingkeyword);
                    $funding_snippets_string=simplexml_load_string($fundingkeyword);
                    
                    $type = $funding_snippets->xpath('//gmd:type'); // xpath returns an array
                    insertBefore($funding_snippets_string, $type[0]);                    
                }
                file_put_contents('test.xml',$funding_snippets->saveXML()); 
                $xml=simplexml_load_file($file_path.$uuid.'_ISO19139.xml');
                $funding_snippets=simplexml_load_file('test.xml');
                $xml->registerXPathNamespace('gmd', 'http://www.isotc211.org/2005/gmd');
                $xml->registerXPathNamespace('gco','http://www.isotc211.org/2005/gco');                            
                $descriptivekeywords = $xml->xpath('//gmd:identificationInfo//gmd:MD_DataIdentification//gmd:descriptiveKeywords'); // xpath returns an array
                if (!empty($descriptivekeywords)) {                            
                    insertAfter($funding_snippets, $descriptivekeywords[0]);
                }                            
              

                file_put_contents($file_path.$uuid.'_ISO19139.xml',$xml->saveXML());
            }
        }
    }
    $record_harvested = fopen('../migrate/logs/'.$env.'/Jer_harvested_records.json', 'w');
    fwrite($record_harvested, json_encode($json_harvested));
    $record_version_mapping = fopen('logs/'.$env.'/Jer_records.json', 'w');
    fwrite($record_version_mapping, json_encode($json_a));
}
?>  