<?php
$env = isset($argv[1]) ? $argv[1] : "stage";
require_once(__DIR__.'/JerHarvester.php');
$host_name=gethostname();
$config=file_get_contents("../jornada_config_".$env.".json");
$config_json = json_decode($config);
$base_url=$config_json->base_url;
$jer_harvester = new JerHarvester($base_url,$config_json,$env);
$jer_harvester->harvest();
